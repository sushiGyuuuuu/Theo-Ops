const contact = {
  eyebrow: "LET'S BUILD SOMETHING USEFUL",
  title: "What are you still doing manually?",
  description:
    "Tell me about a repetitive task or business problem. Let's explore whether automation can make it simpler.",
  button: "Start a Conversation",
  email: "you@example.com", // replace with your real email
  github: "https://github.com/your-username", // replace
  linkedin: "https://www.linkedin.com/in/your-profile", // replace
};

export default contact;